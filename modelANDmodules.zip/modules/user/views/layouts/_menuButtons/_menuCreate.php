<?php

echo CHtml::button('Create', array(
    'submit' => array($controller . '/create'),
    'class' => 'btn btn-sm btn-success'
));
?>