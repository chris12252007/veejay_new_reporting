<?php
    Yii::app()->clientScript->registerScript("javascript", "
        
    $('#grid-pos-transactions').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
    
    $( 'input' ).addClass('form-control' );

    function reinstallDatePicker(id, data) {
        //use the same parameters that you had set in your widget else the datepicker will be refreshed by default
        $('.datePicker').datepicker(jQuery.extend({showMonthAfterYear:false},jQuery.datepicker.regional['ja'],{'dateFormat':'yy-mm-dd'}));

        $( 'input' ).addClass('form-control' );
        $('select').select2({ width: 'resolve' });
        $('.select2-hidden-accessible').attr('hidden', true);
    }
", 2);
?>

<div class="col-md-12">
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Transactions</h3>
            <?php echo CHtml::link('<i class="fa fa-print"></i>', $this->createUrl('posTransactions/print', array('fromDate' => $_GET['fromDate'], 'toDate' => $_GET['toDate'])), array('class' => 'btn btn-xs btn-success pull-right', 'data-toggle' => 'tooltip', 'title' => 'Print')); ?>  </div>
  

        <div class="box-body">
            <table id="grid-pos-transactions" class="table table-bordered table-striped dataTable" width="100%" role="grid">
                <thead>                         
                    <tr>
                        <th style="text-align: center !important; background-color:#3c8dbc;" id="grid-pos-transactions_c0">Customer</th><th style="text-align: center; background-color:#3c8dbc;" id="grid-pos-transactions_c1">Date</th><th style="text-align: center !important; background-color:#3c8dbc;" id="grid-pos-transactions_c2">Item</th><th style="text-align: center; background-color:#3c8dbc;" id="grid-pos-transactions_c3">qty</th><th style="text-align: right; background-color:#3c8dbc;" id="grid-pos-transactions_c4">price</th><th style="text-align: right; background-color:#3c8dbc;" id="grid-pos-transactions_c5">Amount</th><th style="text-align: center !important; background-color:#3c8dbc;" id="grid-pos-transactions_c6">Remarks</th><th style="text-align: right; background-color:#3c8dbc;" id="grid-pos-transactions_c7">Paid</th></tr>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($result->getData() as $data): ?>
                            <tr>
                                <td><?php print $data->customers->lnameFname ?></td>
                                <td><?php print Settings::setDateTimeStandard($data->updated_at) ?></td>
                                <td><?php print $data->inventories->name ?></td>
                                <td><?php print $data->qty ?></td>
                                <td><?php print $data->price ?></td>
                                <td><?php print $data->amount_net ?></td>
                                <td><?php print $data->remarks ?></td>
                                <td><?php print $data->isFullyPaid ?></td>
                            </tr>
                        <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>