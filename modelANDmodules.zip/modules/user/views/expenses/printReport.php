

<div class="col-md-6">
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Generate Expenses Report</h3>
        </div>
        <?php echo $this->renderPartial('_printReportForm', array('model' => $model)); ?>
    </div>
</div>

