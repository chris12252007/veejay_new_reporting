<div class="col-md-5">
    <div class="box box-primary">
        <div class="box-header with-border">
            <h3 class="box-title">Update</h3>
        </div>
        <?php print $this->renderPartial('_formUpdate', array('model' => $model)); ?>
    </div>
</div>